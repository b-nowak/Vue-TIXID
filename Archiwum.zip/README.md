# TIXID
A simple board for storing dixit game result on-the-go.
